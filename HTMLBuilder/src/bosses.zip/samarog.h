#ifndef SAMAROG_H
#define SAMAROG_H

#include "./bosses.h"

class Samarog : public Bosses
{
public:
    Samarog();
private:
    void virtualPure(){}
};

#endif // SAMAROG_H
