#include "sabetha.h"

Sabetha::Sabetha() : Bosses()
{
    this->name = "Sabetha";
    this->imagePath = "<img src=\"../images/173px-Sabetha_the_Saboteur.jpg\">";
    this->htmlFile = "../../Bosses/Sabetha.html";
    this->ressourceDir = "\"../ressources/Sab/";
    this->ressourcePath = "../../ressources/Sab";
}


