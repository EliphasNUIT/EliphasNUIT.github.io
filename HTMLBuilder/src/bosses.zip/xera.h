#ifndef XERA_H
#define XERA_H

#include "./bosses.h"

class Xera : public Bosses
{
public:
    Xera();
private:
    void virtualPure(){}
};

#endif // XERA_H
