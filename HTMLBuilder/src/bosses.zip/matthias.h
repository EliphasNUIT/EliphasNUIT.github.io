#ifndef MATTHIAS_H
#define MATTHIAS_H

#include "./bosses.h"

class Matthias : public Bosses
{
public:
    Matthias();
private:
    void virtualPure(){}
};

#endif // MATTHIAS_H
