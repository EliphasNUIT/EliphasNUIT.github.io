#ifndef CAIRN_H
#define CAIRN_H

#include "./bosses.h"

class Cairn : public Bosses
{
public:
    Cairn();
private:
    void virtualPure(){}
};

#endif // CAIRN_H
