#include "gorseval.h"


Gorseval::Gorseval() : Bosses()
{
    this->name = "Gorseval";
    this->imagePath = "<img src=\"../images/240px-Gorseval_the_Multifarious.jpg\">";
    this->htmlFile = "../../Bosses/Gorseval.html";
    this->ressourceDir = "\"../ressources/Gorse/";
    this->ressourcePath = "../../ressources/Gorse";
}
