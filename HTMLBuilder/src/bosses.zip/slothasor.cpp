#include "slothasor.h"

Slothasor::Slothasor() : Bosses()
{
    this->name = "Slothasor";
    this->imagePath = "<img src=\"../images/240px-Slothasor.jpg\">";
    this->htmlFile = "../../Bosses/Slothasor.html";
    this->ressourceDir = "\"../ressources/Sloth/";
    this->ressourcePath = "../../ressources/Sloth";
}
