#include "deimos.h"

Deimos::Deimos() : Bosses()
{
    this->name = "Deimos";
    this->imagePath = "<img src=\"../images/240px-Deimos.jpg\">";
    this->htmlFile = "../../Bosses/Deimos.html";
    this->ressourceDir = "\"../ressources/Dei/";
    this->ressourcePath = "../../ressources/Dei";
}
