#include "mursaat.h"

Mursaat::Mursaat() : Bosses()
{
    this->name = "Mursaat Overseer";
    this->imagePath = "";//"<img src=\"../images/240px-Cairn_the_Indomitable.jpg\">";
    this->htmlFile = "../../Bosses/Mursaat.html";
    this->ressourceDir = "\"../ressources/MO/";
    this->ressourcePath = "../../ressources/MO";
}


