#ifndef MURSAAT_H
#define MURSAAT_H

#include "./bosses.h"

class Mursaat : public Bosses
{
public:
    Mursaat();
private:
    void virtualPure(){}
};

#endif // MURSAAT_H
