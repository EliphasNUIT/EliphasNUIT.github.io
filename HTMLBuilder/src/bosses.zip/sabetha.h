#ifndef SABETHA_H
#define SABETHA_H

#include "./bosses.h"

class Sabetha : public Bosses
{
public:
    Sabetha();
private:
    void virtualPure(){}
};

#endif // SABETHA_H
