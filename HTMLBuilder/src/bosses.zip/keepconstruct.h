#ifndef KEEPCONSTRUCT_H
#define KEEPCONSTRUCT_H

#include "./bosses.h"

class KeepConstruct : public Bosses
{
public:
    KeepConstruct();
private:
    void virtualPure(){}
};

#endif // KEEPCONSTRUCT_H
