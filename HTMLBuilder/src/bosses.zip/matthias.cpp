#include "matthias.h"

Matthias::Matthias() : Bosses()
{
    this->name = "Matthias";
    this->imagePath = "<img src=\"../images/131px-Matthias_Gabrel.jpg\">";
    this->htmlFile = "../../Bosses/Matthias.html";
    this->ressourceDir = "\"../ressources/Mat/";
    this->ressourcePath = "../../ressources/Mat";
}

