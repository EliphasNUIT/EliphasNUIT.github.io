#ifndef DEIMOS_H
#define DEIMOS_H

#include "./bosses.h"

class Deimos : public Bosses
{
public:
    Deimos();
private:
    void virtualPure(){}
};

#endif // DEIMOS_H
