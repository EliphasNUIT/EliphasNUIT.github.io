#include "samarog.h"

Samarog::Samarog() : Bosses()
{
    this->name = "Samarog";
    this->imagePath = "<img src=\"../images/240px-Samarog.jpg\">";
    this->htmlFile = "../../Bosses/Samarog.html";
    this->ressourceDir = "\"../ressources/Sam/";
    this->ressourcePath = "../../ressources/Sam";
}
